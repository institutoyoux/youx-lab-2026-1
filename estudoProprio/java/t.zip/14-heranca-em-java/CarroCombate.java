public class CarroCombate extends Carro {
    private final int max_arm = 100;
    private final int min_arm = 0;
    private int qtdArm;
    public CarroCombate(String nome, int blindagem) {
        super(nome);
        super.setArmamento(true);
    }
}
