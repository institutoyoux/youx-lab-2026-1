public class main {
    public static void main(String[] args) {
        Carro polo = new Carro("Polo 1.0 turbo 2024");
        polo.info();
        polo.setLigado(true);
        polo.info();
    }
}
