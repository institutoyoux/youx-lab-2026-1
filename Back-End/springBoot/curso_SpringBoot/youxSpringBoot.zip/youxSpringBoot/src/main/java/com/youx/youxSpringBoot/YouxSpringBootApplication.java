package com.youx.youxSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YouxSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(YouxSpringBootApplication.class, args);
	}

}
